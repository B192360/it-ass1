#Reading the given data: 

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

df=pd.read_csv("iris.csv")
